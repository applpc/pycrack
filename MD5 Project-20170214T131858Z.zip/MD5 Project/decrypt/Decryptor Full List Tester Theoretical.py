import itertools
import hashlib
from hashlib import md5
import time
import sys

aaa="47bce5c74f589f4867dbd57e9ca9f808"
aab= "e62595ee98b585153dac87ce1ab69c3c"
aac="a9ced3dad556814ed46042de696e1849"
aad="c2f7ab46df3db842040a86a0897a5377"
aae="cf34362ab126ce8338d8991cc1404980"
aaf="3de47a0c26dcbfde469206be4bd55865"
aag="32ee8ad114363edfb0b9389f79409245"

srchash= raw_input("Hash to be Cracked:")

if srchash==aaa:
    print "aaa"
else:
    if srchash==aab:
        print "aab"
    else:
        if srchash==aac:
            print "aac"
        else:
            if srchash==aad:
                print "aad"
            else:
                if srchash==aae:
                    print"aae"
                else:
                    if srchash==aaf:
                        print"aaf"
                    else:
                        if srchash==aag:
                            print "aag"

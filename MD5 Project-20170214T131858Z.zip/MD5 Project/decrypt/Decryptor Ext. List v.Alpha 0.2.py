import hashlib
import itertools

input_hash = raw_input("What's the Hash that you want to be Cracked?:")
min_limit = raw_input("What is the Minimum Password Length?:")
max_limit = raw_input("What is the Maximum Password Length?:")
min_limit = int(float(min_limit))
max_limit = int(float(max_limit))
dict = "dict.txt"

list= {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '@', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '!', '@', '#', '$', '%', '^', '&', '*', '(', ')', '_', '-', '+', '=', '{', '[', '}', ']', '|'}

file = open("dict.txt", "w")

def randomgen():
    if min_limit<=1 and max_limit>=1:
        for abc in itertools.product(list, repeat = 1):
            randomabc=''.join(abc)
            file.write(randomabc + "\n")
    if min_limit<=2 and max_limit>=2:
        for abc in itertools.product(list, repeat=2):
            randomabc = ''.join(abc)
            file.write(randomabc + "\n")
    if min_limit<= 3 and max_limit>= 3:
        for abc in itertools.product(list, repeat=3):
            randomabc = ''.join(abc)
            file.write(randomabc + "\n")
    if min_limit<= 4 and max_limit>= 4:
        for abc in itertools.product(list, repeat=4):
            randomabc = ''.join(abc)
            file.write(randomabc + "\n")
    if min_limit<= 5 and max_limit>= 5:
        for abc in itertools.product(list, repeat=5):
            randomabc = ''.join(abc)
            file.write(randomabc + "\n")
    if min_limit<= 6 and max_limit>= 6:
        for abc in itertools.product(list, repeat=6):
            randomabc = ''.join(abc)
randomgen()

print("Done Generating Range Combos.")

def main():
    with open(dict) as fileobj:
        for line in fileobj:
            line = line.strip()
            if hashlib.md5(line).hexdigest() == input_hash:
                print (line)
                return ""
    print "Failed to crack the hash."

if __name__ == "__main__":
    print ("Your Password is:")
    print main()





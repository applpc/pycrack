import itertools

min_limit = raw_input("What is the Minimum Password Length?:")
max_limit = raw_input("What is the Maximum Password Length?:")
min_limit = int(float(min_limit))
max_limit = int(float(max_limit))
numrange = range(min_limit, max_limit)
listcount = int(len(numrange) + 1)

#Dictionary File
dict = "dict.txt"

item= 0
numtogen= numrange[item]

list= {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '@', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '!', '@', '#', '$', '%', '^', '&', '*', '(', ')', '_', '-', '+', '=', '{', '[', '}', ']', '|'}

file = open("dict.txt", "w")

#NumGen Seq
def randomgen():
    #Declare Variables as Global
    def numgenmainseq():
        global numtogen
        for i in range(listcount):
            for abc in itertools.product(list, repeat= numtogen):
                randomabc = ''.join(abc)
                file.write(randomabc + "\n")
                numtogen = numrange[item + 1]
            print("Done " , (item))
    numgenmainseq()
    for abc in itertools.product(list, repeat=max_limit):
        randomabc = ''.join(abc)
        file.write(randomabc + "\n")

randomgen()
print("Done Generating Range Combos.")





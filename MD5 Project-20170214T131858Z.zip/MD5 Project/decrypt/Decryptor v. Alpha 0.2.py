import itertools
import hashlib
from hashlib import md5
import time
import sys

#List of Characters Used In Combinations
alphabets = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '@', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']

srchash= raw_input("Hash to be Cracked:")

#Every Possible Combination of Characters Generator
for abc in itertools.product(alphabets, repeat = 3):
    randomabc=''.join(abc)

    def computeMD5hash(randomabc):
        m = hashlib.md5()
        m.update(randomabc.encode('utf-8'))
        return m.hexdigest()
    abchash= computeMD5hash(randomabc)

#If Provided Hash = Generated Hash Print Plain Text
    if abchash==srchash:
        print "There is your password:"
        print abc
        raw_input("Press enter to close")

#4 Digit Tester
for abcd in itertools.product(alphabets, repeat = 4):
    randomabcd=''.join(abcd)

    def computeMD5hash(randomabcd):
        m = hashlib.md5()
        m.update(randomabcd.encode('utf-8'))
        return m.hexdigest()

    abcdhash= computeMD5hash(randomabcd)

    if abcdhash==srchash:
        print "There is your password:"
        print abcd
        raw_input("Press enter to close")

#5 Digit Tester
for abcde in itertools.product(alphabets, repeat = 5):
    randomabcde=''.join(abcde)

    def computeMD5hash(randomabcde):
        m = hashlib.md5()
        m.update(randomabcde.encode('utf-8'))
        return m.hexdigest()

    abcdehash= computeMD5hash(randomabcde)

    if abcdehash==srchash:
        print "There is your password:"
        print abcde
        raw_input("Press enter to close")

#6 Digit Tester
for abcdef in itertools.product(alphabets, repeat = 6):
    randomabcdef=''.join(abcdef)

    def computeMD5hash(randomabcdef):
        m = hashlib.md5()
        m.update(randomabcdef.encode('utf-8'))
        return m.hexdigest()

    abcdefhash= computeMD5hash(randomabcdef)

    if abcdefhash==srchash:
        print "There is your password:"
        print abcdef
        raw_input("Press enter to close")

#7 Digit Tester
for abcdefg in itertools.product(alphabets, repeat = 7):
    randomabcdefg=''.join(abcdefg)

    def computeMD5hash(randomabcdefg):
        m = hashlib.md5()
        m.update(randomabcdefg.encode('utf-8'))
        return m.hexdigest()

    abcdefghash= computeMD5hash(randomabcdefg)

    if abcdefghash==srchash:
        print "There is your password:"
        print abcdefg
        raw_input("Press enter to close")

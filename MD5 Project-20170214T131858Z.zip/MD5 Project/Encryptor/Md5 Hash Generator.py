import hashlib
import itertools

alphabets = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '@', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']

for abc in itertools.product(alphabets, repeat = 3):
    randomabc=''.join(abc)

    def computeMD5hash(randomabc):
        m = hashlib.md5()
        m.update(randomabc.encode('utf-8'))
        return m.hexdigest()
    abchash= computeMD5hash(randomabc)

    print randomabc
    print abchash


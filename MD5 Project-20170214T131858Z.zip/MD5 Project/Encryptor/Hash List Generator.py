import itertools
import string
import hashlib
from hashlib import md5
import time
import sys

list = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']

for abc in itertools.product(list, repeat = 3):
    randomabc=''.join(abc)

    def computeMD5hash(randomabc):
        m = hashlib.md5()
        m.update(randomabc.encode('utf-8'))
        return m.hexdigest()
    abchash= computeMD5hash(randomabc)
    print (randomabc+"="+'"'+abchash+'"')

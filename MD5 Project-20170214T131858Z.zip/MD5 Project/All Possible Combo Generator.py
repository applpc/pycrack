import itertools

list= {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '@', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '!', '@', '#', '$', '%', '^', '&', '*', '(', ')', '_', '-', '+', '=', '{', '[', '}', ']', '|'}

file = open("dict3,4,5.txt", "w")

for abc in itertools.product(list, repeat = 3):
    randomabc=''.join(abc)
    file.write(randomabc + "\n")
for abcd in itertools.product(list, repeat = 4):
    randomabcd=''.join(abcd)
    file.write(randomabcd + "\n")
for abcde in itertools.product(list, repeat = 5):
    randomabcde=''.join(abcde)
    file.write(randomabcde + "\n")
print ("Done")
file.close()


